#!/usr/bin/env bash
# Install and configure SMART monitoring (smartmontools) for the internal SSD.
# Note: the USB SSD is intentionally excluded — SMART passthrough over the
# USB-SATA bridge caused smartd startup failures.

set -euo pipefail

echo "Installing smartmontools..."
sudo apt update
sudo apt install -y smartmontools

echo "Enabling smartd..."
sudo systemctl enable smartd
sudo systemctl start smartd

echo "Running a quick health check on /dev/sda..."
sudo smartctl -H /dev/sda

echo ""
echo "Done. Edit /etc/smartd.conf to tune monitored devices and alert thresholds."
echo "Current pending/reallocated sector counts:"
sudo smartctl -A /dev/sda | grep -E "Reallocated_Sector|Current_Pending_Sector"
