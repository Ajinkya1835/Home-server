#!/usr/bin/env bash
# Set up a LUKS-encrypted HDD and auto-mount it at /mnt/hdd1
#
# WARNING: This will erase the target device. Double check DEVICE before running.
# Usage: sudo ./luks-hdd-setup.sh /dev/sdX

set -euo pipefail

DEVICE="${1:?Usage: $0 /dev/sdX}"
MAPPER_NAME="hdd1_crypt"
MOUNT_POINT="/mnt/hdd1"

echo "About to LUKS-format $DEVICE. This destroys all data on it."
read -p "Type 'yes' to continue: " confirm
[ "$confirm" = "yes" ] || { echo "Aborted."; exit 1; }

echo "Formatting $DEVICE with LUKS..."
sudo cryptsetup luksFormat "$DEVICE"

echo "Opening encrypted volume..."
sudo cryptsetup open "$DEVICE" "$MAPPER_NAME"

echo "Creating filesystem..."
sudo mkfs.ext4 "/dev/mapper/$MAPPER_NAME"

echo "Creating mount point..."
sudo mkdir -p "$MOUNT_POINT"
sudo mount "/dev/mapper/$MAPPER_NAME" "$MOUNT_POINT"

UUID=$(sudo blkid -s UUID -o value "$DEVICE")
echo ""
echo "Add the following to /etc/crypttab:"
echo "$MAPPER_NAME UUID=$UUID none luks"
echo ""
echo "Add the following to /etc/fstab:"
echo "/dev/mapper/$MAPPER_NAME $MOUNT_POINT ext4 defaults 0 2"
echo ""
echo "NOTE: /etc/crypttab as configured will prompt for the passphrase at boot"
echo "unless a keyfile is set up. See docs/storage-setup.md for keyfile automation."
