#!/usr/bin/env bash
# UFW firewall setup for the home server
# Default: deny all incoming, allow all outgoing, then explicitly allow required ports.

set -euo pipefail

echo "Setting default policies..."
sudo ufw default deny incoming
sudo ufw default allow outgoing

echo "Allowing required ports..."
sudo ufw allow 22/tcp        # SSH
sudo ufw allow 2283/tcp      # Immich
sudo ufw allow 3001/tcp      # Uptime Kuma
sudo ufw allow 9000/tcp      # Portainer
sudo ufw allow 19999/tcp     # Netdata

echo "Enabling UFW..."
sudo ufw --force enable

sudo ufw status verbose
