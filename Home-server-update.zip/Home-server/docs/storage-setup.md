# Storage Setup

## SSD (256GB)

Hosts the Ubuntu Server installation, Docker, and system files on the root filesystem (`/`).

## HDD (500GB WD Scorpio Blue)

Used for bulk storage (Immich library, Postgres data, etc.), encrypted at rest with LUKS.

### Setup

See [`scripts/luks-hdd-setup.sh`](../scripts/luks-hdd-setup.sh) for the formatting and mount steps.

### Auto-mount on boot

Two files control this:

**`/etc/crypttab`**
```
hdd1_crypt UUID=<your-device-uuid> none luks
```

**`/etc/fstab`**
```
/dev/mapper/hdd1_crypt /mnt/hdd1 ext4 defaults 0 2
```

By default this prompts for the LUKS passphrase on every boot. To fully automate unlocking at boot (tradeoff: the key material lives on the unencrypted SSD), use a keyfile:

```bash
# Generate a random keyfile
sudo dd if=/dev/urandom of=/root/hdd1.key bs=1024 count=4
sudo chmod 600 /root/hdd1.key

# Add the keyfile as an additional LUKS key
sudo cryptsetup luksAddKey /dev/sdX /root/hdd1.key

# Update crypttab to reference the keyfile instead of "none"
# hdd1_crypt UUID=<uuid> /root/hdd1.key luks
```

Update `/etc/crypttab` accordingly and run `sudo update-initramfs -u`.
