# Recovery Guide — Rebuilding This Server From Scratch

Steps to recreate this home server on a fresh machine.

## 1. Install the OS

- Install **Ubuntu Server 22.04.5 LTS** on the boot drive.
- Update the system:
  ```bash
  sudo apt update && sudo apt upgrade -y
  ```
- Enable SSH during install, or:
  ```bash
  sudo apt install -y openssh-server
  sudo systemctl enable --now ssh
  ```

## 2. Set up storage

- Install and mount the encrypted HDD: see [`storage-setup.md`](storage-setup.md) and [`../scripts/luks-hdd-setup.sh`](../scripts/luks-hdd-setup.sh).

## 3. Install Docker

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
newgrp docker
```

## 4. Deploy services

For each service, copy its `.env.example` to `.env`, fill in the values, and bring it up:

```bash
cd docker-compose/immich && cp .env.example .env && nano .env && docker compose up -d
cd ../portainer && docker compose up -d
cd ../uptime-kuma && docker compose up -d
cd ../netdata && docker compose up -d
```

## 5. Configure the firewall

```bash
sudo ./scripts/firewall-setup.sh
```

## 6. Set up SMART monitoring

```bash
sudo ./scripts/smart-setup.sh
```

## 7. Install sensors

```bash
sudo apt install -y lm-sensors
sudo sensors-detect --auto
```

## 8. Install Tailscale

```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
```

## 9. Deploy the Telegram bot

```bash
cd telegram-bot
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env && nano .env   # fill in bot token + allowed user ID
sudo cp telegram-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now telegram-bot
```

## 10. Verify

- [ ] All containers up: `docker ps`
- [ ] Immich reachable on port 2283
- [ ] Portainer reachable on port 9000
- [ ] Uptime Kuma reachable on port 3001
- [ ] Netdata reachable on port 19999
- [ ] `sudo ufw status verbose` shows expected rules
- [ ] `systemctl status smartd` active
- [ ] `systemctl status telegram-bot` active
- [ ] Tailscale shows the node online, remote SSH works
- [ ] Reboot the machine and confirm everything comes back up automatically
