# Project History

## v1 — Nextcloud + Cloudflare (original)

The project started as a way to avoid paying for extra Google Drive storage: an old laptop was turned into a self-hosted cloud with **Ubuntu Server**, **Nextcloud**, and **Cloudflare** (custom domain + free SSL via Cloudflare).

Original setup steps (kept for reference):
1. Install Ubuntu Server on the old laptop
2. Install and configure Nextcloud
3. Set up a custom domain through Cloudflare, with free SSL/TLS

## v2 — Current: Docker-based home lab

The project has since grown well beyond personal cloud storage into a full home lab:

- Migrated to a **Docker-based** architecture for easier management and isolation
- Added **Immich** for photo/video management
- Added **Portainer**, **Netdata**, and **Uptime Kuma** for management and monitoring
- Added a second, LUKS-encrypted HDD for bulk storage
- Added **Tailscale** for secure remote access, replacing direct port-forwarding
- Added a custom **Telegram bot** for remote server administration
- Added **SMART** and **sensor** monitoring for hardware health

See the main [README](../README.md) for the current architecture and service list.
