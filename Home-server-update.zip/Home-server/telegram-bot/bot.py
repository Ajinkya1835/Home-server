"""
Home Server Telegram Bot
-------------------------
Lets me check status and control the server remotely via Telegram.
Restricted to a single Telegram user ID (set ALLOWED_USER_ID below or via env var).

Fill in / adapt the command handlers to match your actual system —
this is a structural skeleton reflecting the commands documented in the README.
"""

import os
import subprocess
import logging

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
ALLOWED_USER_ID = int(os.environ["TELEGRAM_ALLOWED_USER_ID"])


def restricted(handler):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id != ALLOWED_USER_ID:
            await update.message.reply_text("Unauthorized.")
            return
        await handler(update, context)
    return wrapper


def run(cmd: str) -> str:
    try:
        out = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
        return out.stdout.strip() or out.stderr.strip() or "(no output)"
    except Exception as e:
        return f"Error: {e}"


@restricted
async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uptime = run("uptime -p")
    docker_ps = run("docker ps --format '{{.Names}}: {{.Status}}'")
    await update.message.reply_text(f"Uptime: {uptime}\n\nContainers:\n{docker_ps}")


@restricted
async def temps(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("sensors"))


@restricted
async def ram(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("free -h"))


@restricted
async def cpu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("top -bn1 | head -15"))


@restricted
async def disk(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("df -h"))


@restricted
async def smart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("sudo smartctl -H /dev/sda"))


@restricted
async def uptime_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("uptime -p"))


@restricted
async def docker_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("docker ps --format '{{.Names}}: {{.Status}}'"))


@restricted
async def updates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("apt list --upgradable 2>/dev/null | tail -n +2"))


@restricted
async def services(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(run("systemctl list-units --type=service --state=running | head -20"))


@restricted
async def logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /logs <container>")
        return
    container = context.args[0]
    await update.message.reply_text(run(f"docker logs --tail 30 {container}"))


@restricted
async def restart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /restart <container>")
        return
    container = context.args[0]
    await update.message.reply_text(run(f"docker restart {container}"))


@restricted
async def reboot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Rebooting...")
    run("sudo reboot")


@restricted
async def shutdown(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Shutting down...")
    run("sudo shutdown now")


def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("temps", temps))
    app.add_handler(CommandHandler("ram", ram))
    app.add_handler(CommandHandler("cpu", cpu))
    app.add_handler(CommandHandler("disk", disk))
    app.add_handler(CommandHandler("smart", smart))
    app.add_handler(CommandHandler("uptime", uptime_cmd))
    app.add_handler(CommandHandler("docker", docker_cmd))
    app.add_handler(CommandHandler("updates", updates))
    app.add_handler(CommandHandler("services", services))
    app.add_handler(CommandHandler("logs", logs))
    app.add_handler(CommandHandler("restart", restart))
    app.add_handler(CommandHandler("reboot", reboot))
    app.add_handler(CommandHandler("shutdown", shutdown))

    log.info("Bot starting...")
    app.run_polling()


if __name__ == "__main__":
    main()
